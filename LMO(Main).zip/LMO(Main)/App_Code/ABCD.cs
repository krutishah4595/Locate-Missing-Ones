﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
//using System.Windows.Forms;
using System.Configuration;
using System.Configuration.Provider;

/// <summary>
/// Summary description for ABCD
/// </summary>
public class LMO
{
    public SqlConnection con;
    public SqlCommand cmd;
    public SqlDataAdapter da;
    public DataSet ds;
    public SqlDataReader dr;
    public int i;
    public String s1, s2;
    public object sc;

    public LMO()
    {
        con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        con.Open();
    }

    public int insert(String s)
    {
        try
        {
            cmd = new SqlCommand(s, con);
            i = cmd.ExecuteNonQuery();
            return i;
        }
        catch (Exception e)
        {
           // MessageBox.Show("" + e.Message);
            return 0;
        }
    }

    public object scalar(String str)
    {
        try
        {
            cmd = new SqlCommand(str, con);
            sc = cmd.ExecuteScalar();
            return sc;
        }
        catch (Exception e)
        {
           // MessageBox.Show("" + e.Message);
            return 0;
        }
    }

    public int check(string str)
    {
        try
        {
            cmd = new SqlCommand(str, con);
            dr = cmd.ExecuteReader();
            if (dr.HasRows)
            {
                dr.Close();
                return 1;
            }
            else
            {
                dr.Close();
                return 0;
            }
        }
        catch (Exception e)
        {
            dr.Close();
            return 1;
        }
    }

    public DataSet selectall(string str)
    {
        da = new SqlDataAdapter(str, con);
        ds = new DataSet();
        da.Fill(ds);
        return ds;
    }
}