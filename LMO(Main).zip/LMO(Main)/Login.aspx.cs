﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;

public partial class Login : System.Web.UI.Page
{
    static String strCon = @"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\Admin\Desktop\LMO(Main)\App_Data\Database.mdf;Integrated Security=True;User Instance=True";
        SqlConnection con = new SqlConnection(strCon);

        protected void Page_Load(object sender, EventArgs e)
        {
            txtUName.Focus();
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            string strSel = "Select UserName,Password from RegisteredUser where UserName='" + txtUName.Text.Trim() + "'";
            SqlCommand cmdSel = new SqlCommand(strSel, con);
            SqlDataReader dr;
            if (con.State != ConnectionState.Open)
            {
                con.Open();
            }
            dr = cmdSel.ExecuteReader();
            if (dr.Read()) //valide user name...
            {
                if (dr["Password"].ToString() == txtPswd.Text.Trim())
                {
                    lblErrMsg.Text = "Login Suceessful...";
                }
                else
                {
                    lblErrMsg.Text = "Invalid Password...";
                    txtPswd.Text = "";
                    txtPswd.Focus();
                }
            }
            else //Invalide user name...
            {
                lblErrMsg.Text = "Invalide Username...";
                txtUName.Text = "";
                txtUName.Focus();
            }

        }
}