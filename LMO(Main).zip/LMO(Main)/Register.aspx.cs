﻿using System;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;


public partial class Register : System.Web.UI.Page
{

    static String strCon = @"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\Admin\Desktop\LMO(Main)\App_Data\Database.mdf;Integrated Security=True;User Instance=True";
    SqlConnection con = new SqlConnection(strCon);
    
    protected void Page_Load(object sender, EventArgs e)
    {
       //if (!Page.IsPostBack)
       //{
       //     rfvEmail.Visible = false;
       //     rfvMNo.Visible = false;
       // }
    }
    protected void btnCAcc_Click(object sender, EventArgs e)
    {
        string strSel = "Select * from RegisteredUser where UserName='" + txtUName.Text.Trim() + "'";
        SqlDataAdapter adptSel = new SqlDataAdapter();
        DataSet ds = new DataSet();
        if (con.State != ConnectionState.Open)
        {
            con.Open();
        }

        adptSel.SelectCommand = new SqlCommand(strSel, con);
        adptSel.Fill(ds);
        con.Close();
        if (ds.Tables[0].Rows.Count > 0)
        {
            lblErrMsg.Text = "Please enter another user name";
            txtUName.Text = "";
            txtUName.Focus();
        }
        else
        {
            string strGen;
            if (rbGender.SelectedValue == "Male")
            {
                strGen = "Male";
            }
            else if (rbGender.SelectedValue == "Female")
            {
                strGen = "Female";
            }
            else if (rbGender.SelectedValue == "Other")
            {
                strGen = "Other";
            }
            string strIns;
            strIns = "Insert into RegisteredUser(FirstName,LastName,Address1,Address2,Address3,CityId,StateId,CountryId,Pincode,Gender,BirthDate,EmailId,MobileNo,UserName,Password,SQuestion,Answer,Status) values('" + txtFName.Text + "','" + txtLName.Text + "','" + txtAdd1.Text + "','" + txtAdd2.Text + "','" + txtAdd3.Text + "','" + ddCity.Text + "','" + ddState.Text + "','" + ddCountry.Text + "','" + txtPinCode.Text + "','" + rbGender.Text + "','" + Calendar1.ToString() + "','" + txtEmail.Text + "','" + txtMNo.Text + "','" + txtUName.Text + "','" + txtPswd.Text + "','" + ddSQue.Text + "','" + txtGAns.Text + "','" + ddMStatus.Text + "')";
            if (con.State != ConnectionState.Open)
            {
                con.Open();
            }
            SqlDataAdapter adptIns = new SqlDataAdapter();
            adptIns.InsertCommand = new SqlCommand(strIns, con);
            adptIns.InsertCommand.ExecuteNonQuery();
            con.Close();
            lblErrMsg.Text = "Data Inserted Successfully....";
        }
    }

         
 }
    